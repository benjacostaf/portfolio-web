<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Prop_pastina extends Model{
    protected $fillable = [
        'id',
        'color',
        'junta',
        'tamaño'
    ];
}